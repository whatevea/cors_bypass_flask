export const checkGrammar = (text) => {
    const grammarRules = {
        // Capitalization rules
        startsWithCapital: text.charAt(0) === text.charAt(0).toUpperCase(),
        properNouns: /(monday|tuesday|wednesday|thursday|friday|saturday|sunday|january|february|march|april|may|june|july|august|september|october|november|december)/i,

        // Punctuation rules
        endsWithPunctuation: /[.!?]$/.test(text),
        hasExcessivePunctuation: /[!?]{2,}/.test(text),

        // Spacing rules
        hasDoubleSpaces: /\s{2,}/.test(text),
        spacesBeforePunctuation: /\s+[.,!?]/.test(text),

        // Common word pairs and confusions
        commonMistakes: {
            "your": "you're",
            "their": "they're",
            "there": "they're",
            "its": "it's",
            "loose": "lose",
            "whose": "who's",
            "affect": "effect",
            "then": "than",
            "to": "too",
            "alot": "a lot",
            "could of": "could have",
            "should of": "should have",
            "would of": "would have",
            "im": "I'm",
            "dont": "don't",
            "cant": "can't",
            "wont": "won't",
            "wasnt": "wasn't",
            "didnt": "didn't",
            "isnt": "isn't",
            "wouldnt": "wouldn't",
            "shouldnt": "shouldn't",
            "couldnt": "couldn't",
            "werent": "weren't",
            "arent": "aren't"
        },

        // Redundant phrases
        redundantPhrases: [
            "absolutely essential",
            "advance planning",
            "basic fundamentals",
            "completely filled",
            "end result",
            "final outcome",
            "future plans",
            "past history",
            "repeat again",
            "revert back"
        ],

        // Subject-verb agreement checks
        subjectVerbPairs: {
            "i is": "I am",
            "they is": "they are",
            "we is": "we are",
            "he are": "he is",
            "she are": "she is",
            "it are": "it is"
        }
    };

    const errors = [];

    // Check capitalization
    if (!grammarRules.startsWithCapital) {
        errors.push("Sentence should start with a capital letter");
    }

    // Check proper nouns
    const properNounMatches = text.match(grammarRules.properNouns);
    if (properNounMatches) {
        properNounMatches.forEach(match => {
            if (match.charAt(0) !== match.charAt(0).toUpperCase()) {
                errors.push(`"${match}" should be capitalized`);
            }
        });
    }

    // Check punctuation
    if (!grammarRules.endsWithPunctuation) {
        errors.push("Sentence should end with proper punctuation");
    }
    if (grammarRules.hasExcessivePunctuation) {
        errors.push("Avoid using multiple exclamation or question marks");
    }

    // Check spacing
    if (grammarRules.hasDoubleSpaces) {
        errors.push("Remove double spaces");
    }
    if (grammarRules.spacesBeforePunctuation) {
        errors.push("Remove spaces before punctuation marks");
    }

    // Check common word mistakes
    const words = text.toLowerCase().split(" ");
    words.forEach((word, index) => {
        if (word in grammarRules.commonMistakes) {
            errors.push(`Consider using "${grammarRules.commonMistakes[word]}" instead of "${word}"`);
        }
    });

    // Check redundant phrases
    grammarRules.redundantPhrases.forEach(phrase => {
        if (text.toLowerCase().includes(phrase)) {
            errors.push(`"${phrase}" is redundant. Consider rephrasing.`);
        }
    });

    // Check subject-verb agreement
    Object.keys(grammarRules.subjectVerbPairs).forEach(pair => {
        if (text.toLowerCase().includes(pair)) {
            errors.push(`"${pair}" should be "${grammarRules.subjectVerbPairs[pair]}"`);
        }
    });

    // Additional checks for sentence structure
    if (text.length < 5) {
        errors.push("Message is too short for a meaningful argument");
    }

    if (text.split(' ').length < 3) {
        errors.push("Please form a complete sentence");
    }

    // Check for repeated words
    const repeatedWords = text.toLowerCase().split(' ').filter((word, index, arr) =>
        word.length > 3 && word === arr[index - 1]
    );
    if (repeatedWords.length > 0) {
        errors.push(`Repeated word detected: "${repeatedWords[0]}"`);
    }

    return {
        isValid: errors.length === 0,
        errors: errors,
        text: text
    };
};
