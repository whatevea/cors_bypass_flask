import { sendPasswordResetEmail, signInWithPopup } from "firebase/auth";
import { auth, googleProvider } from "../firebase";
import { getCoins } from "../backend/coins";

export const Auth = ({ setUser }) => {
    const signInWithGoogle = async () => {
        let result = await signInWithPopup(auth, googleProvider)
        let user = result.user
        let coins = await getCoins(user.uid)
        let userDetails = {
            uid: user.uid,
            name: user.displayName,
            email: user.email,
            image: user.photoURL,
            coins: coins
        }
        localStorage.userDetails = JSON.stringify(userDetails);
        setUser(userDetails)
    }
    return (
        <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 to-indigo-100">
            <div className="bg-white p-8 rounded-xl shadow-2xl transform hover:scale-105 transition-transform duration-300">
                <h1 className="text-3xl font-bold text-center mb-8 text-gray-800">Welcome to Game Hub</h1>
                <button
                    onClick={signInWithGoogle}
                    className="flex items-center justify-center space-x-3 bg-white border-2 border-gray-200 rounded-lg px-6 py-3 w-full hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 transition-all duration-300"
                >
                    <img src="https://www.google.com/favicon.ico" alt="Google" className="w-6 h-6" />
                    <span className="text-gray-700 font-medium">Sign in with Google</span>
                </button>
            </div>
        </div>
    )
}
