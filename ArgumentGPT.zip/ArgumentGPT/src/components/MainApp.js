import React, { useState, useRef, useEffect } from "react";
import { collection, doc, getDoc, onSnapshot, setDoc, updateDoc } from "firebase/firestore";
import { UserDetail } from "./userDetails";
import { db } from "../firebase";
import { generateRandomRoomId } from "../backend/extras";
import axios from "axios";
import { GameCanvas } from "./GameCanvas";

export const MainApp = () => {
    const [roomId, setRoomId] = useState(null);
    const [messages, setMessages] = useState({});
    const [result, setResult] = useState(null);
    const [gameData, setGameData] = useState(null);
    const [_docRef, setDocRef] = useState();
    const inputRef = useRef(null);
    const roomsRef = collection(db, "rooms");
    const uid = JSON.parse(localStorage.getItem("userDetails"))?.uid;

    const attachHook = () => {
        if (!_docRef) return;

        const unsubscribe = onSnapshot(_docRef, (doc) => {
            try {
                const data = doc.data();
                if (!data) {
                    console.error("No data found in the document");
                    return;
                }

                if (gameData === null && data.gameId) {
                    setGameData(data);
                }

                if (data.messages !== messages) {
                    setMessages(data.messages);

                    const messageCount = Object.values(data.messages).reduce(
                        (count, userMessages) => count + userMessages.length,
                        0
                    );

                    if (messageCount >= 6) {
                        const toBackend = {
                            type: "Result",
                            gameId: data.gameId,
                            question: data.questions,
                            answers: data.messages
                        };

                        axios.post("https://argumentgpt-server.sandiph.workers.dev", toBackend)
                            .then((res) => {
                                try {
                                    const result = res.data;
                                    setResult(result);
                                } catch (parseError) {
                                    console.error("Error parsing result:", parseError);
                                    console.log("Raw response data:", res.data);
                                }
                            })
                            .catch((error) => {
                                console.error("Error fetching result:", error);
                            });
                    }
                }
            } catch (error) {
                console.error("Error in attachHook:", error);
            }
        });

        return unsubscribe;
    };

    useEffect(() => {
        const unsubscribe = attachHook();
        return () => {
            if (unsubscribe) unsubscribe();
        };
    }, [_docRef]);

    const hostRoom = async () => {
        try {
            const newRoomId = generateRandomRoomId();
            setRoomId(newRoomId);

            const data = {
                result: {},
                questions: {},
                messages: { [uid]: [] },
                users: [uid],
                gameId: "",
                answers: {},
                gameStarter: uid
            };

            const docRef = doc(roomsRef, newRoomId);
            setDocRef(docRef);
            await setDoc(docRef, data);
        } catch (error) {
            console.error("Error in hostRoom:", error);
        }
    };

    const joinRoom = async () => {
        try {
            const newRoomId = inputRef.current.value;
            setRoomId(newRoomId);

            const docRef = doc(roomsRef, newRoomId);
            setDocRef(docRef);

            const docu = (await getDoc(docRef)).data();
            if (!docu) {
                console.error("No document found for the given room ID");
                return;
            }

            docu.users.push(uid);
            docu.messages[uid] = [];
            await updateDoc(docRef, docu);

            const toBackend = {
                users: docu.users,
                roomId: newRoomId,
                reqType: "GameStart"
            };

            const res = await axios.post("https://argumentgpt-server.sandiph.workers.dev", toBackend);
            const gameData = res.data;

            await updateDoc(docRef, {
                gameId: gameData.gameId,
                questions: gameData.qa.questions,
                answers: gameData.qa.answers
            });
        } catch (error) {
            console.error("Error in joinRoom:", error);
        }
    };

    if (!uid) {
        return <div>Please log in to access the game.</div>;
    }

    return (
        <div className="min-h-screen bg-gray-100 p-8">
            {gameData ? (
                <GameCanvas result={result} gamedata={gameData} docRef={_docRef} messages={messages} />
            ) : (
                <div className="max-w-4xl mx-auto bg-white rounded-lg shadow-md p-6">
                    <h1 className="text-3xl font-bold mb-6 text-center text-indigo-600">Argument GPT Chat Game</h1>

                    {roomId && (
                        <p className="text-lg font-semibold mb-4 text-center">
                            Connected Room ID: <span className="text-green-600">{roomId}</span>
                        </p>
                    )}

                    <div className="mb-6">
                        <h2 className="text-xl font-semibold mb-2">User Details</h2>
                        <UserDetail />
                    </div>

                    <div className="flex flex-col md:flex-row justify-center items-center gap-4">
                        <button
                            className="bg-indigo-600 text-white px-6 py-2 rounded-md hover:bg-indigo-700 transition duration-300 ease-in-out"
                            onClick={hostRoom}
                        >
                            Host Game
                        </button>

                        <div className="flex items-center">
                            <input
                                ref={inputRef}
                                className="border-2 border-gray-300 rounded-l-md px-4 py-2 focus:outline-none focus:border-indigo-500"
                                placeholder="Enter Room ID"
                            />
                            <button
                                className="bg-green-600 text-white px-6 py-2 rounded-r-md hover:bg-green-700 transition duration-300 ease-in-out"
                                onClick={joinRoom}
                            >
                                Join Game
                            </button>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};