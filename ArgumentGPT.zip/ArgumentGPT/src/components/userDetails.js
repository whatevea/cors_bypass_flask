import React from "react";
import { signOut } from "firebase/auth";
import { auth } from "../firebase";

export const UserDetail = () => {
    const user = JSON.parse(localStorage.userDetails);

    return (
        <div className="flex items-center justify-between bg-white rounded-lg shadow-md p-4">
            <div className="flex items-center space-x-4">
                <img
                    className="w-12 h-12 rounded-full object-cover"
                    src={user.image}
                    alt={user.name}
                />
                <div>
                    <p className="font-semibold text-gray-800">{user.name}</p>
                    <p className="text-sm text-gray-600">Coins: {user.coins}</p>
                </div>
            </div>
            <button
                onClick={() => signOut(auth)}
                className="bg-red-500 text-white px-4 py-2 rounded-md hover:bg-red-600 transition duration-300 ease-in-out"
            >
                Sign Out
            </button>
        </div>
    );
};