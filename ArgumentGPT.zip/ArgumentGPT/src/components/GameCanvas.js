import React, { useRef, useState, useEffect } from "react";
import { getDoc, updateDoc } from "firebase/firestore";
import confetti from 'canvas-confetti';
import { checkGrammar } from "../grammarCheck";
import { toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

export const GameCanvas = ({ result, docRef, messages, gamedata }) => {
    const uid = JSON.parse(localStorage.userDetails).uid;
    const inputRef = useRef(null);
    const [showResult, setShowResult] = useState(false);

    useEffect(() => {
        if (result) {
            setShowResult(true);
            if (result.winner === uid) {
                confetti({
                    particleCount: 100,
                    spread: 70,
                    origin: { y: 0.6 }
                });
            }
        }
    }, [result, uid]);

    const onSubmit = () => {
        let text = inputRef.current.value;
        const grammarCheck = checkGrammar(text);

        if (!grammarCheck.isValid) {
            grammarCheck.errors.forEach(error => {
                toast.warning(error, {
                    position: "top-right",
                    autoClose: 3000,
                    hideProgressBar: false,
                    closeOnClick: true,
                    pauseOnHover: true,
                    draggable: true,
                });
            });
            return;
        }

        sendMessage(text);
        inputRef.current.value = "";
    };

    const sendMessage = async (text) => {
        const messagesObj = (await getDoc(docRef)).data().messages;
        messagesObj[uid].push(text);
        await updateDoc(docRef, { messages: messagesObj });
    };

    const ResultDisplay = () => {
        if (!result) return null;

        const isWinner = result.winner === uid;

        return (
            <div className={`mt-6 p-6 rounded-lg shadow-lg ${isWinner ? 'bg-green-100' : 'bg-red-100'}`}>
                <h2 className={`text-3xl font-bold mb-4 ${isWinner ? 'text-green-600' : 'text-red-600'}`}>
                    {isWinner ? '🎉 Congratulations! You Won! 🏆' : '😔 Better Luck Next Time!'}
                </h2>
                <p className="text-lg mb-4">
                    <span className="font-semibold">Judge's Decision:</span> {result.reason}
                </p>
                <div className="mt-4">
                    <button
                        onClick={() => setShowResult(false)}
                        className="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600 transition duration-300"
                    >
                        Back to Game
                    </button>
                </div>
            </div>
        );
    };

    return (
        <div className="max-w-4xl mx-auto bg-white rounded-lg shadow-md p-6">
            {showResult ? (
                <ResultDisplay />
            ) : (
                <>
                    <h1 className="text-2xl font-bold mb-6 text-center text-indigo-600">Argument Arena</h1>

                    <div className="mb-6">
                        <p className="text-lg font-semibold mb-2">
                            Question: <span className="text-gray-700">{gamedata.questions}</span>
                        </p>
                        <p className="text-lg font-semibold mb-4">
                            Your Position: <span className="text-indigo-600 font-bold">{gamedata.answers[uid]}</span>
                        </p>
                        <p className="text-xl font-semibold mb-2">Make Your Case:</p>
                    </div>

                    <div className="border-2 border-gray-200 rounded-md p-4 h-64 mb-4 overflow-y-auto">
                        {Object.entries(messages).map(([userId, userMessages]) => (
                            <div key={userId} className="mb-2">
                                <p className="font-semibold">{userId === uid ? "You" : "Opponent"}:</p>
                                {userMessages.map((msg, index) => (
                                    <p key={index} className={`ml-4 ${userId === uid ? 'text-blue-600' : 'text-green-600'}`}>
                                        {msg}
                                    </p>
                                ))}
                            </div>
                        ))}
                    </div>

                    <div className="flex gap-2">
                        <input
                            ref={inputRef}
                            className="flex-grow border-2 border-gray-300 rounded-md px-4 py-2 focus:outline-none focus:border-indigo-500"
                            placeholder="Type your argument here..."
                        />
                        <button
                            onClick={onSubmit}
                            className="bg-indigo-600 text-white px-6 py-2 rounded-md hover:bg-indigo-700 transition duration-300 ease-in-out"
                        >
                            Submit Argument
                        </button>
                    </div>
                </>
            )}
        </div>
    );
};