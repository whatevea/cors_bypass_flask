//this will contain all the things that will happen when the game is matched.
    